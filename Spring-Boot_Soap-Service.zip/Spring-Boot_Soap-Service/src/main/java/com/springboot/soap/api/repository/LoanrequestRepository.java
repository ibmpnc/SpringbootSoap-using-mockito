package com.springboot.soap.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanrequestRepository extends JpaRepository<Loanrequest, Integer>{

}
